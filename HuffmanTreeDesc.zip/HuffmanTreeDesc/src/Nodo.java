import java.io.*;

class Nodo implements Serializable {
    private static final long serialVersionUID = -7412975203537303337L;

    char caracter;
    Nodo izquierda, derecha;

    public Nodo(char caracter) {
        this.caracter = caracter;
    }

    public boolean esHoja() {
        return izquierda == null && derecha == null;
    }
}