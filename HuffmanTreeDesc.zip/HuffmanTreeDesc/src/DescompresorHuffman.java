import java.io.*;
import java.util.*;
public class DescompresorHuffman {

    public static Nodo cargarArbol(String archivoArbol) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(archivoArbol))) {
            return (Nodo) input.readObject();
        }
    }

    public static String descomprimir(String archivoHuffman, Nodo raiz) throws IOException {
        StringBuilder mensaje = new StringBuilder();
        try (DataInputStream input = new DataInputStream(new FileInputStream(archivoHuffman))) {
            while (input.available() > 0) {
                Nodo actual = raiz;
                while (!actual.esHoja()) {
                    boolean bit = input.readBoolean();
                    actual = bit ? actual.derecha : actual.izquierda;
                }
                mensaje.append(actual.caracter);
            }
        }
        return mensaje.toString();
    }

    public static void escribirArchivo(String mensaje, String nombreArchivo) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            writer.write(mensaje);
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        String archivoHuffman = "arbol.huff";
        String archivoArbol = "arbol.tree";
        String archivoTextoDesc = "textodesc.txt";

        // Cargar el árbol de Huffman desde el archivo .tree
        Nodo raiz = cargarArbol(archivoArbol);

        // Descomprimir el archivo .huff utilizando el árbol de Huffman
        String mensaje = descomprimir(archivoHuffman, raiz);

        // Escribir el mensaje descomprimido en un archivo
        escribirArchivo(mensaje, archivoTextoDesc);

        System.out.println("Mensaje descomprimido guardado en el archivo: " + archivoTextoDesc);
    }
}