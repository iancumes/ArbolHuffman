import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;

public class DescompresorHuffmanTest {

    @Test
    public void testCargarArbol() throws IOException, ClassNotFoundException {
        // Crea un árbol de prueba
        Nodo raiz = new Nodo('a');
        // Guarda el árbol en un archivo
        String archivoArbol = "arbol.tree";
        ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(archivoArbol));
        output.writeObject(raiz);
        output.close();

        // Carga el árbol desde el archivo
        Nodo arbolCargado = DescompresorHuffman.cargarArbol(archivoArbol);

        // Comprueba si el árbol cargado es igual al árbol de prueba
        assertEquals(raiz.caracter, arbolCargado.caracter);
    }

    

    @Test
    public void testEscribirArchivo() throws IOException {
        // Crea un mensaje de prueba
        String mensaje = "Hola, mundo!";
        // Escribe el mensaje en un archivo de prueba
        String archivoTextoDesc = "test.txt";
        DescompresorHuffman.escribirArchivo(mensaje, archivoTextoDesc);

        // Lee el archivo y comprueba si el contenido es igual al mensaje de prueba
        BufferedReader reader = new BufferedReader(new FileReader(archivoTextoDesc));
        String linea = reader.readLine();
        reader.close();
        assertEquals(mensaje, linea);
    }
}
